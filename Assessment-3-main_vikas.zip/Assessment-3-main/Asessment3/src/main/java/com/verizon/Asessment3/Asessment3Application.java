package com.verizon.Asessment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Asessment3Application {

	public static void main(String[] args) {
		SpringApplication.run(Asessment3Application.class, args);
	}

}
